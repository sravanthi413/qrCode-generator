import React from 'react';
import QRCode from 'qrcode';
import './qr.css';
export default function App(){
    const[url,setUrl]=React.useState('');
    const[qrcode,setQrcode]=React.useState('');
    const GenerateQrCode=()=>{
        QRCode.toDataURL(url,{
            //here we can go with so many options which we want to add it to our qrcode
            width:800,
            margin:2,
            color:{
                dark:'#000000ff',
                light:'#ffffffff'
            }
        },(err,url)=>{ //This line calls the toDataURL method of the QRCode module.
            // This method generates a Data URL (base64-encoded image) of a QR code for the specified URL
            //(err,url)-callback function ,executed once the QR code generation is complete
            if(err) return console.log(err)
            
          setQrcode(url)//update state variable'qrcode' with the generated dataURL of the QR code image
        })
    }
    return(
        <>
        <div className='app'>
            <h1>QR Code Generator</h1>
             <input type='text'
             placeholder='e.g:https://google.com'
             value={url}
             onChange={(event)=>setUrl(event.target.value)}/>
             <button onClick={GenerateQrCode}>Generate</button>
           {/* here we are using conditional rendering,only when the qrcode exist,then only we can download it */}
           {qrcode && <>
            <img src={qrcode} />
            <a href={qrcode} download="qrcode.png">Download</a>
           </>}
          
        </div>
        </>
    )
}